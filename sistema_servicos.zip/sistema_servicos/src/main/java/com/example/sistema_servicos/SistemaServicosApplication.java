package com.example.sistema_servicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaServicosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaServicosApplication.class, args);
	}

}
